

void EXTInit(void);