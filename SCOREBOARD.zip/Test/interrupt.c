#include "interrupt.h"
#include "stm32f10x.h"
void EXTInit(void)
{
	//Page references for Interrupt
	//ENABLE AFIO CLOCK 
	RCC->APB2ENR |= RCC_APB2ENR_AFIOEN;
	//CHOOSE PORT b
	AFIO->EXTICR[2] |= AFIO_EXTICR3_EXTI8_PB;
	//UNMASK PA0
	EXTI->IMR |= EXTI_IMR_MR8;
	//SELECT FALLING EDGE
	EXTI->RTSR |= EXTI_RTSR_TR8;
	//UNMASK EXTI0
	NVIC_EnableIRQ(EXTI9_5_IRQn);
}

